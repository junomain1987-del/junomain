// Copies the Scratch engine (TurboWarp scaffolding, shipped inside @turbowarp/packager)
// into ./engine so the site serves it from its own domain. No CDN is needed at runtime.
import { cpSync, existsSync, mkdirSync, readdirSync, rmSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const src = join(root, 'node_modules', '@turbowarp', 'packager', 'dist', 'scaffolding');
const out = join(root, 'engine');

if (!existsSync(src)) {
  console.error('\nEngine files not found at ' + src + '\nRun "npm install" first.\n');
  process.exit(1);
}

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
cpSync(src, out, { recursive: true });

const files = readdirSync(out).filter((f) => statSync(join(out, f)).isFile());
if (!files.includes('scaffolding-full.js')) {
  console.error('\nExpected engine/scaffolding-full.js but found: ' + files.join(', ') + '\n');
  process.exit(1);
}
console.log('Engine bundled into ./engine: ' + files.join(', '));
