(function () {
  var $ = function (id) { return document.getElementById(id); };
  var stageEl = $('stage'), overlay = $('overlay'), logEl = $('log');
  var sc = null, vm = null, loadedName = '';
  var settings = { interp: true, turbo: true, hq: true, fps: 250 };
  var saved = null; try { saved = JSON.parse(localStorage.getItem('tyshawn-settings') || '{}'); Object.assign(settings, saved); } catch (_) {}
  var ENGINE_URLS = ['engine/scaffolding-full.js','https://cdn.jsdelivr.net/npm/@turbowarp/packager@3.13.0/dist/scaffolding/scaffolding-full.js','https://unpkg.com/@turbowarp/packager@3.13.0/dist/scaffolding/scaffolding-full.js'];
  var engineRate = 0, displayRate = 0, engineSamples = 0, engineSampleStart = 0, engineListener = null;
  function log(t, cls) { logEl.className='log'+(cls?' '+cls:'');logEl.textContent=t||''; }
  function esc(s){return String(s).replace(/[&<>\"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
  function showOverlay(html){overlay.innerHTML='<div class="box">'+html+'</div>';overlay.classList.add('show')}
  function hideOverlay(){overlay.classList.remove('show')}
  function loadScript(src){return new Promise(function(resolve,reject){var s=document.createElement('script');s.src=src;s.async=true;s.onload=function(){resolve()};s.onerror=function(){s.remove();reject(new Error('could not load '+src))};document.head.appendChild(s)})}
  function loadEngine(){var errors=[];function attempt(i){if(window.Scaffolding)return Promise.resolve();if(i>=ENGINE_URLS.length){var err=new Error('The game engine could not be loaded.');err.details=errors.join('\n');return Promise.reject(err)}return loadScript(ENGINE_URLS[i]).then(function(){if(!window.Scaffolding)throw new Error(ENGINE_URLS[i]+' loaded but did not define Scaffolding')}).catch(function(e){errors.push(e.message);return attempt(i+1)})}return attempt(0)}
  function numericFps(){
    if(settings.fps==='unlocked'||settings.fps===0) return 250;
    var n=Number(settings.fps);
    return Number.isFinite(n)?Math.max(1,Math.min(250,n)):250;
  }
  function detachEngineMeter(){
    if(vm && vm.runtime && vm.runtime.removeListener && engineListener){ try{vm.runtime.removeListener('AFTER_EXECUTE', engineListener)}catch(_){} }
    engineListener=null; engineSamples=0; engineSampleStart=performance.now(); engineRate=0;
  }
  function attachEngineMeter(){
    detachEngineMeter();
    if(!vm || !vm.runtime || !vm.runtime.on) return;
    engineSampleStart=performance.now();
    engineListener=function(){
      engineSamples++;
      var now=performance.now(), dt=now-engineSampleStart;
      if(dt>=500){ engineRate=Math.round(engineSamples*1000/dt); engineSamples=0; engineSampleStart=now; }
    };
    try{vm.runtime.on('AFTER_EXECUTE',engineListener)}catch(_){}
  }
  function applySettings(){
    if(!vm)return;
    var fps=numericFps();
    try{if(vm.runtime&&vm.runtime.frameLoop&&vm.runtime.frameLoop.setFramerate)vm.runtime.frameLoop.setFramerate(fps)}catch(e){}
    try{if(vm.setFramerate)vm.setFramerate(fps)}catch(e){}
    try{if(vm.setInterpolation)vm.setInterpolation(!!settings.interp)}catch(e){}
    try{if(vm.setTurboMode)vm.setTurboMode(!!settings.turbo)}catch(e){}
    try{if(vm.runtime&&vm.runtime.setCompilerOptions)vm.runtime.setCompilerOptions({enabled:true})}catch(e){}
    try{if(vm.renderer&&vm.renderer.setUseHighQualityRender)vm.renderer.setUseHighQualityRender(!!settings.hq)}catch(e){}
  }
  function persist(){try{localStorage.setItem('tyshawn-settings',JSON.stringify(settings))}catch(_){}
  }
  function updateRateUI(){
    if($('fps')) $('fps').textContent = engineRate ? ('Engine '+engineRate+' FPS') : 'Engine — FPS';
    if($('displayFps')) $('displayFps').textContent = displayRate ? ('Display '+displayRate+' FPS') : 'Display — FPS';
  }
  function start(name,buffer){
    loadedName=name;$('title').textContent=name;document.title=name+" · Tyshawn's Engine";
    showOverlay('<div class="spinner"></div><h2>Loading '+esc(name)+'</h2><p>Starting the high-performance Scratch runtime…</p>');
    return loadEngine().then(function(){
      var NS=window.Scaffolding,Ctor=NS.Scaffolding||NS;
      if(sc){try{sc.vm.stopAll()}catch(e){}detachEngineMeter();stageEl.innerHTML=''}
      sc=new Ctor();sc.width=480;sc.height=360;sc.resizeMode='preserve-ratio';sc.editableLists=false;sc.shouldConnectPeripherals=false;sc.setup();sc.appendTo(stageEl);vm=sc.vm;
      attachEngineMeter();applySettings();
      return sc.loadProject(buffer);
    }).then(function(){
      applySettings();sc.start();hideOverlay();
      log('Engine target: '+numericFps()+' FPS • measuring script execution separately from display refresh.');
    }).catch(function(e){
      var msg=e&&e.message?e.message:String(e),det=e&&e.details?'<pre>'+esc(e.details)+'</pre>':'';
      showOverlay('<h2>Could not start this game</h2><p>'+esc(msg)+'</p>'+det+'<p>Make sure the file is a Scratch 3 project (<code>.sb3</code>).</p><div class="actions"><button class="primary" id="retry">Try again</button><a class="home" href="index.html">Back to engine</a></div>');
      var r=$('retry');if(r)r.onclick=function(){start(name,buffer.slice?buffer.slice(0):buffer)};log('Failed to start.','err');if(window.console)console.error(e)
    });
  }
  function readFile(f){if(!f)return;if(!/\.sb3$/i.test(f.name)){log('Please choose an .sb3 file.','err');return}var r=new FileReader();r.onload=function(){start(f.name,r.result)};r.onerror=function(){log('Could not read that file.','err')};r.readAsArrayBuffer(f)}
  $('go').onclick=function(){if(sc)sc.greenFlag()};
  $('stop').onclick=function(){if(sc)sc.stopAll()};
  $('fs').onclick=function(){var el=stageEl;(el.requestFullscreen||el.webkitRequestFullscreen||function(){log('Fullscreen is not supported here.','err')}).call(el)};
  function toggle(btnId,key,onLabel,offLabel){var b=$(btnId);function paint(){b.classList.toggle('on',!!settings[key]);b.textContent=settings[key]?onLabel:offLabel}b.onclick=function(){settings[key]=!settings[key];paint();applySettings();persist()};paint()}
  toggle('interp','interp','Smooth: On','Smooth: Off');toggle('turbo','turbo','Turbo: On','Turbo: Off');
  $('fpsMode').value=(settings.fps==='unlocked'||Number(settings.fps)>=250)?'unlocked':String(settings.fps);
  $('fpsMode').onchange=function(){settings.fps=this.value==='unlocked'?'unlocked':Number(this.value);persist();applySettings();log('Engine target set to '+numericFps()+' FPS. The display can still refresh at its own hardware/browser rate.')};

  (function(){
    var n=0,last=performance.now();
    function tick(now){
      n++;
      if(now-last>=500){displayRate=Math.round(n*1000/(now-last));n=0;last=now;updateRateUI();}
      requestAnimationFrame(tick)
    }
    requestAnimationFrame(tick)
  })();

  document.addEventListener('dragover',function(e){e.preventDefault()});document.addEventListener('drop',function(e){e.preventDefault();readFile(e.dataTransfer.files[0])});
  var id=new URLSearchParams(location.search).get('id');
  if(!id){showOverlay('<h2>Choose a Scratch game</h2><p>Go back to the engine and import an <code>.sb3</code>, or use Discover to pull a public Scratch project into the player.</p><div class="actions"><a class="home" href="index.html">Open Tyshawn\'s Engine</a></div>');return}
  window.GameStore.get(id).then(function(rec){if(!rec||!rec.data){showOverlay('<h2>Game not found</h2><p>That upload is missing from this browser vault.</p><div class="actions"><a class="home" href="index.html">Upload it again</a></div>');return}return start(rec.name,rec.data)}).catch(function(e){showOverlay('<h2>Could not read your game</h2><p>'+esc(e&&e.message||e)+'</p><p>Browser storage may be blocked. You can return to the home screen and import the file again.</p><div class="actions"><a class="home" href="index.html">Back to engine</a></div>')});
})();
