(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var current = null;
  var tabs = ['home', 'discover', 'ai', 'performance'];
  var state = { fps: 250, turbo: true, interp: true, hq: true };
  var expressions = [
    'neutral','happy','excited','laughing','wink','love','blush','smug','confident','proud',
    'thinking','confused','curious','surprised','shocked','worried','sad','crying','angry','annoyed',
    'frustrated','scared','sleepy','bored','disgusted','embarrassed','nervous','determined','shy','serious'
  ];

  function say(t, c) { var e = $('msg'); if (!e) return; e.textContent = t || ''; e.className = 'inline-message ' + (c || ''); }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]; }); }
  function formatSize(n) { return window.formatSize ? window.formatSize(n) : (n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'); }

  function showTab(tab) {
    if (tabs.indexOf(tab) < 0) tab = 'home';
    tabs.forEach(function (k) {
      var section = $('tab-' + k); if (section) section.classList.toggle('active', k === tab);
    });
    Array.prototype.forEach.call(document.querySelectorAll('.nav-link'), function (b) { b.classList.toggle('active', b.getAttribute('data-tab') === tab); });
    if (history.replaceState) history.replaceState(null, '', '#' + tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (tab === 'home') renderRecent();
    if (tab === 'performance') { renderPerf(); runDiagnostics(); }
    if (tab === 'ai') runAIHealth();
  }

  Array.prototype.forEach.call(document.querySelectorAll('[data-tab]'), function (b) { b.addEventListener('click', function () { showTab(b.getAttribute('data-tab')); }); });
  Array.prototype.forEach.call(document.querySelectorAll('[data-tab-jump]'), function (b) { b.addEventListener('click', function () { showTab(b.getAttribute('data-tab-jump')); }); });
  $('openRecent').addEventListener('click', function () { showTab('home'); setTimeout(function () { ($('recentPanel') || document.body).scrollIntoView({ behavior: 'smooth' }); }, 60); });

  function handleFile(f) {
    if (!f) return;
    if (!/\.sb3$/i.test(f.name)) { say('Please choose a Scratch 3 .sb3 project.', 'err'); return; }
    var r = new FileReader();
    r.onload = function () {
      current = { name: f.name, data: r.result, size: f.size };
      $('fname').textContent = f.name; $('fsize').textContent = formatSize(f.size) + ' • ready'; $('loaded').classList.add('show');
      say('Game loaded. Pick a launch mode.', 'ok');
    };
    r.onerror = function () { say('Could not read that file.', 'err'); };
    r.readAsArrayBuffer(f);
  }
  function launch(newTab) {
    if (!current) { say('Choose an .sb3 file first.', 'err'); return; }
    var win = newTab ? window.open('about:blank', '_blank') : null;
    if (newTab && !win) say('Your browser blocked the new tab. Launching here instead.', 'err');
    window.GameStore.put(current.name, current.data).then(function (id) {
      var url = 'play.html?id=' + encodeURIComponent(id);
      return rememberGame(id, current.name).then(function () {
        if (win) { win.location.href = url; say('Opened the player in a new tab.', 'ok'); }
        else location.href = url;
      });
    }).catch(function (e) { if (win) win.close(); say('Could not store the game: ' + (e.message || e), 'err'); });
  }
  $('file').addEventListener('change', function () { handleFile($('file').files[0]); });
  $('heroUpload').addEventListener('click', function () { $('file').click(); });
  ['dragenter','dragover'].forEach(function (ev) { $('drop').addEventListener(ev, function (e) { e.preventDefault(); $('drop').classList.add('over'); }); });
  ['dragleave','drop'].forEach(function (ev) { $('drop').addEventListener(ev, function (e) { e.preventDefault(); $('drop').classList.remove('over'); }); });
  $('drop').addEventListener('drop', function (e) { handleFile(e.dataTransfer.files[0]); });
  $('drop').addEventListener('click', function () { $('file').click(); });
  $('newtab').addEventListener('click', function () { launch(true); }); $('here').addEventListener('click', function () { launch(false); });

  function rememberGame(id, name) {
    try {
      var arr = JSON.parse(localStorage.getItem('tyshawn-recent') || '[]').filter(function (x) { return x && x.id !== id; });
      arr.unshift({ id: id, name: name, t: Date.now() }); localStorage.setItem('tyshawn-recent', JSON.stringify(arr.slice(0, 12)));
    } catch (_) {}
    return Promise.resolve();
  }
  function recent() { try { return JSON.parse(localStorage.getItem('tyshawn-recent') || '[]'); } catch (_) { return []; } }
  function renderRecent() {
    var box = $('recentList'), arr = recent();
    if (!arr.length) { box.innerHTML = '<div class="empty-inline"><b>No local games yet.</b><span>Import an .sb3 or play one from Discover.</span></div>'; return; }
    box.innerHTML = arr.map(function (x) { return '<button class="recent-item" data-recent="' + esc(x.id) + '"><span class="file-badge">SB3</span><span><b>' + esc(x.name) + '</b><small>' + new Date(x.t).toLocaleString() + '</small></span><span>▶</span></button>'; }).join('');
    Array.prototype.forEach.call(box.querySelectorAll('[data-recent]'), function (b) { b.onclick = function () { location.href = 'play.html?id=' + encodeURIComponent(b.getAttribute('data-recent')); }; });
  }
  $('clearRecent').onclick = function () { localStorage.removeItem('tyshawn-recent'); renderRecent(); };

  // Scratch search
  function scratchFetch(path, opts) { return fetch(path, opts).then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) throw new Error(j.error || ('Request failed (' + r.status + ')')); return j; }); }); }
  function searchScratch(q) {
    var results = $('scratchResults'); results.innerHTML = '<div class="search-loading glass"><div class="spinner"></div><b>Searching Scratch…</b></div>';
    $('searchMeta').textContent = 'Searching for “' + q + '”…';
    scratchFetch('/api/scratch-search?q=' + encodeURIComponent(q || 'trending') + '&limit=24').then(function (data) {
      var items = Array.isArray(data) ? data : (data && (data.projects || data.results || data.items) || []);
      if (!items.length) { results.innerHTML = '<div class="empty-card glass"><div>∅</div><b>No projects found</b><span>Try a broader search.</span></div>'; return; }
      $('searchMeta').textContent = items.length + ' projects found';
      results.innerHTML = items.map(gameCard).join('');
      Array.prototype.forEach.call(results.querySelectorAll('[data-project-id]'), function (b) { b.onclick = function () { importScratchProject(b.getAttribute('data-project-id'), b); }; });
    }).catch(function (e) {
      results.innerHTML = '<div class="empty-card glass"><div>!</div><b>Scratch search is offline</b><span>' + esc(e.message || e) + '</span><button class="secondary" id="retryScratch">Try again</button></div>';
      var retry = $('retryScratch'); if (retry) retry.onclick = function () { searchScratch(q); };
    });
  }
  function normalizeGame(g) {
    return { id: g.id || g.project_id, title: g.title || g.name || 'Untitled Scratch Project', author: (g.author && (g.author.username || g.author)) || g.username || 'Scratch user', instructions: g.instructions || '', loves: g.stats ? g.stats.loves : (g.loves || 0), favorites: g.stats ? g.stats.favorites : (g.favorites || 0) };
  }
  function gameCard(raw) {
    var g = normalizeGame(raw); if (!g.id) return '';
    var thumb = 'https://uploads.scratch.mit.edu/projects/thumbnails/' + encodeURIComponent(g.id) + '.png';
    return '<article class="game-card glass"><img loading="lazy" src="' + thumb + '" alt="" onerror="this.style.visibility=\'hidden\'"><div class="game-body"><div class="game-title"><b>' + esc(g.title) + '</b><span>#' + esc(g.id) + '</span></div><small>by ' + esc(String(g.author)) + '</small><div class="game-metrics"><span>♥ ' + Number(g.loves || 0).toLocaleString() + '</span><span>★ ' + Number(g.favorites || 0).toLocaleString() + '</span></div><div class="button-row"><button class="primary" data-project-id="' + esc(g.id) + '">▶ Add &amp; Play</button><a class="ghost-btn" href="https://scratch.mit.edu/projects/' + encodeURIComponent(g.id) + '/" target="_blank" rel="noreferrer">View</a></div></div></article>';
  }
  function importScratchProject(id, button) {
    button.disabled = true; button.textContent = 'Loading…';
    fetch('/api/scratch-project?id=' + encodeURIComponent(id)).then(function (r) { if (!r.ok) throw new Error('Scratch project download failed (' + r.status + ')'); return r.arrayBuffer(); }).then(function (buf) {
      return window.GameStore.put('Scratch Project ' + id + '.sb3', buf).then(function (storeId) { return rememberGame(storeId, 'Scratch Project ' + id + '.sb3').then(function () { location.href = 'play.html?id=' + encodeURIComponent(storeId); }); });
    }).catch(function (e) { button.disabled = false; button.textContent = '▶ Add & Play'; alert('Could not import this project. ' + (e.message || e)); });
  }
  $('scratchSearch').onclick = function () { searchScratch($('scratchQuery').value.trim() || 'trending'); };
  $('searchTrending').onclick = function () { $('scratchQuery').value = ''; searchScratch('trending'); };
  $('scratchQuery').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('scratchSearch').click(); });

  // AI diagnostics
  function runAIHealth() {
    var e = $('aiHealth'); if (!e) return; e.textContent = 'Checking…'; e.className = 'ai-health';
    fetch('/api/health', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) { e.textContent = j.aiConfigured ? 'AI ready' : 'AI server ready • key missing'; e.className = 'ai-health ' + (j.aiConfigured ? 'good' : 'warn'); }).catch(function () { e.textContent = 'Local API not reachable'; e.className = 'ai-health bad'; });
  }
  $('aiCheck').onclick = function () {
    var pre = $('aiDiagnostics'); pre.textContent = 'Checking /api/health…';
    fetch('/api/health', { cache: 'no-store' }).then(function (r) { return r.json().then(function (j) { return { status: r.status, j: j }; }); }).then(function (x) { pre.textContent = JSON.stringify(x.j, null, 2) + '\nHTTP ' + x.status + '\nBrowser origin: ' + location.origin; runAIHealth(); }).catch(function (e) { pre.textContent = 'FAILED\n' + (e.message || e) + '\nOrigin: ' + location.origin; });
  };

  expressions.forEach(function (name) {
    var wrap = document.createElement('div'); wrap.className = 'expression-tile';
    wrap.innerHTML = '<div class="expr-face"><img alt="' + name + '" data-expr="' + name + '" src="expressions/' + name + '.png"></div><span>' + name + '</span>';
    var img = wrap.querySelector('img');
    img.onerror = function () {
      var step = Number(img.dataset.fallback || 0);
      var next = ['webp','jpg','jpeg','gif','svg'][step];
      if (next) { img.dataset.fallback = String(step + 1); img.src = 'expressions/' + name + '.' + next; } else { img.onerror = null; }
    };
    $('expressionGrid').appendChild(wrap);
  });
  $('openExpressions').onclick = function () { alert('Replace any file inside the expressions/ folder. Preferred order: PNG → WEBP → JPG → JPEG → GIF → SVG. The chat will use your image when it is available.'); };

  // Settings + performance
  function saveSettings() { localStorage.setItem('tyshawn-settings', JSON.stringify(state)); }
  function loadSettings() { try { var x = JSON.parse(localStorage.getItem('tyshawn-settings') || '{}'); Object.assign(state, x); } catch (_) {} }
  function renderPerf() {
    var box = $('fpsButtons'); var modes = [30,60,120,180,240,'unlocked'];
    box.innerHTML = modes.map(function (n) { return '<button class="fps-choice ' + (String(state.fps) === String(n) ? 'active' : '') + '" data-fps="' + n + '">' + n + (n === 'unlocked' ? '' : ' FPS') + '</button>'; }).join('');
    Array.prototype.forEach.call(box.querySelectorAll('[data-fps]'), function (b) { b.onclick = function () { state.fps = b.getAttribute('data-fps') === 'unlocked' ? 'unlocked' : Number(b.getAttribute('data-fps')); saveSettings(); renderPerf(); }; });
    $('settingTurbo').checked = !!state.turbo; $('settingInterp').checked = !!state.interp; $('settingHQ').checked = !!state.hq;
    $('settingTurbo').onchange = function () { state.turbo = this.checked; saveSettings(); }; $('settingInterp').onchange = function () { state.interp = this.checked; saveSettings(); }; $('settingHQ').onchange = function () { state.hq = this.checked; saveSettings(); };
    $('meterFill').style.width = (state.fps === 'unlocked' ? 100 : Math.min(100, Number(state.fps) / 2.5)) + '%';
    $('renderNote').textContent = state.fps === 'unlocked' ? 'Target: TurboWarp max 250 FPS' : 'Target: ' + state.fps + ' FPS';
  }
  function runDiagnostics() {
    var box = $('diagList'), tests = [
      ['Browser', navigator.userAgent ? 'Detected' : 'Unknown', true],
      ['WebAssembly', typeof WebAssembly !== 'undefined' ? 'Available' : 'Missing', typeof WebAssembly !== 'undefined'],
      ['IndexedDB', !!window.indexedDB ? 'Available' : 'Missing', !!window.indexedDB],
      ['RequestAnimationFrame', typeof requestAnimationFrame === 'function' ? 'Available' : 'Missing', typeof requestAnimationFrame === 'function'],
      ['Shared Origin', location.protocol !== 'file:' ? 'HTTP(S) server active' : 'File:// mode', location.protocol !== 'file:'],
      ['API health', 'Checking…', null]
    ];
    box.innerHTML = tests.map(function (t) { return '<div class="diag-row"><span>' + t[0] + '</span><b class="' + (t[2] === false ? 'bad' : t[2] === true ? 'good' : '') + '">' + t[1] + '</b></div>'; }).join('');
    fetch('/api/health', { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (j) { var el = box.lastElementChild && box.lastElementChild.querySelector('b'); if (el) { el.textContent = j.ok ? 'Reachable' : 'Issue'; el.className = j.ok ? 'good' : 'bad'; } }).catch(function () { var el = box.lastElementChild && box.lastElementChild.querySelector('b'); if (el) { el.textContent = 'Offline'; el.className = 'bad'; } });
  }
  $('runDiagnostics').onclick = runDiagnostics;
  $('wipeVault').onclick = function () { if (!confirm('Delete local game storage from this browser?')) return; indexedDB.deleteDatabase('tyshawns-scratch-engine'); localStorage.removeItem('tyshawn-recent'); renderRecent(); updateStorage(); alert('Local vault cleared.'); };
  function updateStorage() { var el = $('storageStat'); if (!navigator.storage || !navigator.storage.estimate) { el.textContent = 'Browser storage estimate unavailable'; return; } navigator.storage.estimate().then(function (x) { el.textContent = ((x.usage || 0) / 1048576).toFixed(1) + ' MB used • ' + ((x.quota || 0) / 1048576).toFixed(0) + ' MB available'; }); }
  function theme() { var dark = document.documentElement.dataset.theme !== 'dark'; document.documentElement.dataset.theme = dark ? 'dark' : ''; localStorage.setItem('tyshawn-theme', dark ? 'dark' : 'light'); }
  $('themeBtn').onclick = theme;
  try { if (localStorage.getItem('tyshawn-theme') === 'dark') document.documentElement.dataset.theme = 'dark'; } catch (_) {}
  loadSettings(); renderPerf(); renderRecent(); updateStorage(); runAIHealth();
  if (location.hash) showTab(location.hash.slice(1)); else showTab('home');

  // global import shortcut
  document.addEventListener('keydown', function (e) { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'o') { e.preventDefault(); $('file').click(); } });
  document.addEventListener('settingsready', renderPerf);
  window.TyshawnApp = { showTab: showTab, importScratchProject: importScratchProject, state: state };
})();
