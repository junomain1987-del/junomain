// Cloudflare Pages Function: served at /api/sans
import { handleChat } from '../../lib/sans-core.mjs';

const headers = { 'content-type': 'application/json', 'cache-control': 'no-store' };

export async function onRequestPost({ request, env }) {
  let body;
  try { body = await request.json(); } catch { return new Response(JSON.stringify({ error: 'bad_request' }), { status: 400, headers }); }
  const ip = request.headers.get('cf-connecting-ip') || 'unknown';
  const { status, json } = await handleChat(body, { apiKey: env.ANTHROPIC_API_KEY, model: env.ANTHROPIC_MODEL, ip });
  return new Response(JSON.stringify(json), { status, headers });
}
