const headers = { 'content-type': 'application/json', 'cache-control': 'public, max-age=60' };
export async function onRequestGet({ request }) {
  const url = new URL(request.url), q = (url.searchParams.get('q') || 'trending').slice(0, 160), limit = Math.min(40, Math.max(1, Number(url.searchParams.get('limit') || 24)));
  try {
    const r = await fetch('https://api.scratch.mit.edu/search/projects?q=' + encodeURIComponent(q) + '&mode=trending&language=en&offset=0&limit=' + limit, { headers: { accept: 'application/json' } });
    return new Response(await r.text(), { status: r.status, headers });
  } catch (e) { return new Response(JSON.stringify({ error: 'scratch_upstream', message: e.message }), { status: 502, headers }); }
}
