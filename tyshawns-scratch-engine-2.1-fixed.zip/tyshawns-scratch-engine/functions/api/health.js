const headers = { 'content-type': 'application/json', 'cache-control': 'no-store' };
export async function onRequestGet({ env }) {
  return new Response(JSON.stringify({ ok: true, server: "Tyshawn's Engine Cloudflare API", aiConfigured: !!env.ANTHROPIC_API_KEY, model: env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', scratchProxy: true }), { status: 200, headers });
}
