// Sans chat UI. Expression images are replaceable files in ./expressions/.
(function () {
  var INK = '#2b2350';
  var G = 'fill="none" stroke="' + INK + '" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"';
  var DOT = function (x, y, r) { return '<circle cx="' + x + '" cy="' + y + '" r="' + (r || 3.6) + '" fill="' + INK + '" stroke="none"/>'; };
  var FACES = {
    neutral: '<path d="M32 46h12M56 46h12"/><path d="M43 61h14"/>',
    happy: '<path d="M32 49q6-9 12 0M56 49q6-9 12 0"/><path d="M40 57q10 13 20 0z" fill="' + INK + '"/>',
    excited: '<circle cx="38" cy="45" r="6" fill="#fff"/><circle cx="62" cy="45" r="6" fill="#fff"/>' + DOT(38,45,2) + DOT(62,45,2) + '<path d="M39 58q11 12 22 0z" fill="' + INK + '"/>',
    laughing: '<path d="M31 42l10 4-10 4M69 42l-10 4 10 4"/><path d="M38 56q12 18 24 0z" fill="' + INK + '"/>',
    wink: DOT(38,46) + '<path d="M56 46h12"/><path d="M42 61q10 6 18-3"/>',
    love: '<path d="M32 46l6-5 6 5-6 7zM56 46l6-5 6 5-6 7z" fill="#ff5a9d" stroke="none"/><path d="M40 62q10 10 20 0"/>',
    blush: '<path d="M32 46h12M56 46h12"/><path d="M41 61q9 7 18 0"/><path d="M27 55h8M65 55h8" stroke="#ff6cae"/>',
    smug: '<path d="M33 49a5 5 0 0 1 10 0z" fill="' + INK + '"/><path d="M57 49a5 5 0 0 1 10 0z" fill="' + INK + '"/><path d="M32 41l12-2M69 41l-12-2"/><path d="M32 61q9 4 18-2"/>',
    confident: '<path d="M31 43h14M55 43h14"/><path d="M42 60q8 5 16 0"/>',
    proud: '<path d="M31 44q7-4 14 0M55 44q7-4 14 0"/><path d="M41 60q9 7 18 0"/><path d="M50 28v-7M44 23l6-6 6 6"/>',
    thinking: DOT(41,43) + DOT(65,43) + '<path d="M44 62h12"/><circle cx="80" cy="30" r="2.2" fill="' + INK + '" stroke="none"/><circle cx="86" cy="21" r="3.4" fill="' + INK + '" stroke="none"/>',
    confused: DOT(38,46) + DOT(62,45) + '<path d="M44 62q7-5 14 0"/><path d="M31 39q6-6 12 0M57 39q7 6 12 0"/>',
    curious: DOT(38,45) + DOT(62,45) + '<path d="M43 61q8 4 14-2"/><path d="M31 37q6-3 12 0M57 37q6-3 12 0"/>',
    surprised: '<circle cx="38" cy="45" r="6.5" fill="#fff"/><circle cx="62" cy="45" r="6.5" fill="#fff"/>' + DOT(38,45,2.2) + DOT(62,45,2.2) + '<ellipse cx="50" cy="63" rx="4" ry="5.5" fill="' + INK + '"/>',
    shocked: '<circle cx="38" cy="44" r="7" fill="#fff"/><circle cx="62" cy="44" r="7" fill="#fff"/>' + DOT(38,44,2.6) + DOT(62,44,2.6) + '<ellipse cx="50" cy="65" rx="5.5" ry="8" fill="' + INK + '"/>',
    worried: DOT(38,47) + DOT(62,47) + '<path d="M31 38l12 4M69 38l-12 4"/><path d="M42 66q8-7 16 0"/>',
    sad: DOT(38,47) + DOT(62,47) + '<path d="M31 38l12 4M69 38l-12 4"/><path d="M42 66q8-7 16 0"/><path d="M33 54q-2 5 0 7" stroke="#4d97ff"/>',
    crying: '<circle cx="38" cy="46" r="6" fill="#fff"/><circle cx="62" cy="46" r="6" fill="#fff"/>' + DOT(38,46,2) + DOT(62,46,2) + '<path d="M34 53v12M66 53v12" stroke="#4d97ff"/><path d="M42 66q8-6 16 0"/>',
    angry: DOT(38,47) + DOT(62,47) + '<path d="M31 39l12-6M69 39l-12-6"/><path d="M42 63h16"/><path d="M44 63l-3 4M56 63l3 4"/>',
    annoyed: DOT(38,47) + DOT(62,47) + '<path d="M31 41l12-2M69 41l-12-2"/><path d="M43 63h14"/>',
    frustrated: DOT(38,47) + DOT(62,47) + '<path d="M31 38l12 4M69 38l-12 4"/><path d="M41 65q9-4 18 0"/><path d="M23 28l8 4M77 28l-8 4"/>',
    scared: '<circle cx="38" cy="45" r="7" fill="#fff"/><circle cx="62" cy="45" r="7" fill="#fff"/>' + DOT(38,45,2.2) + DOT(62,45,2.2) + '<path d="M42 64q8-5 16 0"/><path d="M31 38q7-7 13-1M69 38q-7-7-13-1"/>',
    sleepy: '<path d="M32 47q6 5 12 0M56 47q6 5 12 0"/><ellipse cx="50" cy="62" rx="3" ry="4"/><text x="72" y="30" font-size="13" font-weight="800" fill="' + INK + '" stroke="none">z</text><text x="80" y="20" font-size="9" font-weight="800" fill="' + INK + '" stroke="none">z</text>',
    bored: '<path d="M32 46h12M56 46h12"/><path d="M43 64h14"/><path d="M50 28v-7"/>',
    disgusted: '<path d="M32 48q6 5 12 0M56 48q6 5 12 0"/><path d="M42 63q8-5 16 0"/><path d="M45 56q5-5 10 0" stroke="#57aa77"/>',
    embarrassed: DOT(38,46) + DOT(62,46) + '<path d="M42 61q8 5 16 0"/><ellipse cx="33" cy="55" rx="7" ry="3" fill="#ff5a9d" opacity=".5" stroke="none"/><ellipse cx="67" cy="55" rx="7" ry="3" fill="#ff5a9d" opacity=".5" stroke="none"/>',
    nervous: '<path d="M32 46l5-3 7 3M56 46l5-3 7 3"/><path d="M43 64h14"/><path d="M28 31l-5 6M72 31l5 6"/>',
    determined: DOT(38,47) + DOT(62,47) + '<path d="M31 39l12 2M69 39l-12 2"/><path d="M41 63q9-6 18 0"/>',
    shy: '<path d="M32 48h12M56 48h12"/><path d="M43 62q7 4 14 0"/><ellipse cx="32" cy="56" rx="8" ry="3" fill="#ff5a9d" opacity=".35" stroke="none"/><ellipse cx="68" cy="56" rx="8" ry="3" fill="#ff5a9d" opacity=".35" stroke="none"/>',
    serious: DOT(38,47) + DOT(62,47) + '<path d="M31 41l12 2M69 41l-12 2"/><path d="M43 63h14"/>'
  };
  var MOODS = Object.keys(FACES);
  var BODY = '<path d="M18 92V48C18 24 32 12 50 12S82 24 82 48V92l-8-7-8 7-8-7-8 7-8-7-8 7-8-7-8 7z" fill="#eef6ff" stroke="' + INK + '" stroke-width="3" stroke-linejoin="round"/>' +
             '<ellipse cx="29" cy="56" rx="5" ry="3" fill="#ff4d9d" opacity=".35"/><ellipse cx="71" cy="56" rx="5" ry="3" fill="#ff4d9d" opacity=".35"/>' +
             '<path d="M22 74q28 10 56 0v8q-28 10-56 0z" fill="#ff9f1a" stroke="' + INK + '" stroke-width="3" stroke-linejoin="round"/>';

  function svgAvatar(mood) { return '<svg viewBox="0 0 100 100" role="img" aria-label="Character feeling ' + mood + '">' + BODY + '<g ' + G + '>' + (FACES[mood] || FACES.neutral) + '</g></svg>'; }
  function imageAvatar(mood) {
    var safe = /^[a-z0-9_-]+$/i.test(mood) ? mood : 'neutral';
    // The browser will use the first file that exists. Users may replace any image.
    return '<img src="expressions/' + safe + '.png" data-expr-img="' + safe + '" alt="' + safe + ' expression" onerror="TyshawnChat.handleExpressionError(this)"/>';
  }
  function avatar(mood) { return imageAvatar(MOODS.indexOf(mood) >= 0 ? mood : 'neutral'); }

  var history = [], busy = false, mood = 'neutral', typer = null, imageFallbacks = {};
  function setBusy(v){ busy=!!v; if(!els.send)return; els.send.disabled=busy; els.input.disabled=busy; els.send.textContent=busy?'Thinking…':'Send'; }
  var els = {};
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; }
  function handleExpressionError(img) {
    var moodName = img.getAttribute('data-expr-img') || 'neutral', n = imageFallbacks[moodName] || 0;
    var candidates = ['webp','jpg','jpeg','gif','svg'];
    if (n < candidates.length) { imageFallbacks[moodName] = n + 1; img.src = 'expressions/' + moodName + '.' + candidates[n]; }
    else { img.onerror = null; img.outerHTML = svgAvatar(moodName); }
  }

  function build() {
    var back = el('div', 'chat-back');
    var d = el('aside', 'chat-drawer'); d.setAttribute('role','dialog'); d.setAttribute('aria-label','Chat with Sans'); d.setAttribute('aria-hidden','true');
    d.innerHTML = '<header class="chat-head"><div class="chat-av idle" id="chatAv"></div><div class="chat-who"><b>Sans</b><span id="chatStatus">feeling neutral</span></div><button class="chat-x" id="chatX" aria-label="Close chat">✕</button></header>' +
      '<div class="chat-log" id="chatLog" aria-live="polite"></div><div class="chat-chips" id="chatChips"></div>' +
      '<form class="chat-form" id="chatForm"><input id="chatIn" type="text" maxlength="600" placeholder="say something…" autocomplete="off" aria-label="Message"><button type="submit" id="chatSend">Send</button></form>';
    document.body.appendChild(back); document.body.appendChild(d);
    els = { drawer:d, back:back, av:d.querySelector('#chatAv'), status:d.querySelector('#chatStatus'), log:d.querySelector('#chatLog'), chips:d.querySelector('#chatChips'), form:d.querySelector('#chatForm'), input:d.querySelector('#chatIn'), send:d.querySelector('#chatSend') };
    ['Tell me a joke','Give me a pun','How do I use this engine?','Help me make a Scratch game'].forEach(function (t) { var c=el('button','chip',t); c.type='button'; c.onclick=function(){ask(t)}; els.chips.appendChild(c); });
    ['keydown','keyup','keypress'].forEach(function(ev){els.input.addEventListener(ev,function(e){e.stopPropagation();})});
    els.form.onsubmit=function(e){e.preventDefault();var t=els.input.value.trim();if(t){els.input.value='';ask(t)}};
    d.querySelector('#chatX').onclick=close; back.onclick=close; document.addEventListener('keydown',function(e){if(e.key==='Escape')close()});
    Array.prototype.forEach.call(document.querySelectorAll('[data-open-chat]'),function(b){b.addEventListener('click',open)});
    Array.prototype.forEach.call(document.querySelectorAll('[data-av]'),function(n){n.innerHTML=avatar(n.getAttribute('data-av'))});
    setMood('neutral'); say('heya. the engine’s got a new control room. ask me anything.', 'happy', true);
  }
  function setMood(m, anim) { mood=MOODS.indexOf(m)>=0?m:'neutral'; els.av.innerHTML=avatar(mood); els.status.textContent='feeling '+mood; els.av.classList.remove('hop','shake'); void els.av.offsetWidth; if(anim) els.av.classList.add(anim); }
  function open(){els.drawer.classList.add('open');els.back.classList.add('open');els.drawer.setAttribute('aria-hidden','false');setTimeout(function(){els.input.focus()},250)}
  function close(){if(!els.drawer)return;els.drawer.classList.remove('open');els.back.classList.remove('open');els.drawer.setAttribute('aria-hidden','true')}
  function scroll(){els.log.scrollTop=els.log.scrollHeight}
  function bubble(who,text){var b=el('div','msg '+who);b.textContent=text;els.log.appendChild(b);scroll();return b}
  function say(text,m,instant){var b=bubble('bot','');setMood(m||'neutral',(m==='laughing'||m==='surprised'||m==='shocked'||m==='excited')?'shake':'hop');if(instant||window.matchMedia('(prefers-reduced-motion: reduce)').matches){b.textContent=text;return Promise.resolve()}return new Promise(function(resolve){var i=0;els.av.classList.add('talking');clearInterval(typer);typer=setInterval(function(){i=Math.min(text.length,i+2);b.textContent=text.slice(0,i);scroll();if(i>=text.length){clearInterval(typer);els.av.classList.remove('talking');resolve()}},17)})}
  function localFallback(text) {
    var t=String(text||'').toLowerCase();
    if(/^(hi|hey|heya|hello|yo)\b/.test(t)) return {mood:'happy',text:"heya. you're back. what's on the agenda?"};
    if(/joke|pun|funny/.test(t)) return {mood:'laughing',text:"why did the sprite stop talking to the bug? because it kept making bad choices. ...yeah, that's my level of comedy."};
    if(/fps|frame rate|framerate|performance|turbo/.test(t)) return {mood:'thinking',text:'the player can target up to 250 custom engine FPS. the browser display can still visibly refresh at 60 hz, so engine execution rate and display FPS are two different numbers.'};
    if(/expression|emotion|face|mood/.test(t)) return {mood:'happy',text:'the expression library has 30 moods. replace the matching file in expressions/ with your own image and keep the emotion filename.'};
    if(/scratch|sb3|project|game/.test(t)) return {mood:'curious',text:'use Home to import an .sb3 or Discover to find public Scratch projects. then open the player and run it with the engine controls.'};
    if(/papyrus|brother/.test(t)) return {mood:'happy',text:"papyrus? that's my brother. way too much energy. good intentions, though. don't tell him i admitted that."};
    if(/sad|upset|cry|lonely|hurt/.test(t)) return {mood:'serious',text:"hey... i'm listening. no punchline needed. tell me what's going on and we'll take it one step at a time."};
    return {mood:'chill',text:"heh. i got you. the server brain isn't reachable right now, so i'm in local mode — but i'm still listening. tell me the next thing you want to figure out."};
  }
  function ask(text){if(busy)return;els.chips.style.display='none';bubble('me',text);history.push({role:'user',content:text});setBusy(true);setMood('thinking');var typing=el('div','msg bot typing','…');els.log.appendChild(typing);scroll();var ctl=new AbortController(),to=setTimeout(function(){ctl.abort()},45000);
    fetch('/api/sans',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages:history}),signal:ctl.signal}).then(function(r){return r.json().catch(function(){return{}}).then(function(j){return{ok:r.ok,status:r.status,j:j}})}).then(function(r){clearTimeout(to);typing.remove();if(r.ok&&r.j.reply){history.push({role:'assistant',content:r.j.reply});return say(r.j.reply,r.j.mood)}history.pop();var msg=r.j.error==='not_configured'?"the local AI bridge is working, but no ANTHROPIC_API_KEY is configured. i can still use local helper mode.":r.status===404?null:r.j.error==='slow_down'?'whoa. rate limit hit — give me a moment.':r.j.error==='upstream'?'the AI provider returned an error. check the server key/model settings.':'something went sideways. run the AI connection check on the AI Lab tab.';if(msg===null){var fb=localFallback(text);return say(fb.text,fb.mood)}return say(msg,r.j.error==='slow_down'?'worried':'sad')}).catch(function(e){clearTimeout(to);typing.remove();history.pop();var fb=localFallback(text);return say(fb.text,fb.mood)}).then(function(){setBusy(false)})}
  window.TyshawnChat={open:open,close:close,avatar:avatar,moods:MOODS,handleExpressionError:handleExpressionError,svgAvatar:svgAvatar};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',build);else build();
})();
