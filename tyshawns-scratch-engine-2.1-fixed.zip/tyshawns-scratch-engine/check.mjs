import { handleChat, cleanMessages, parseReply } from './lib/sans-core.mjs';

const tests = [];
const ok = (name, condition) => tests.push({name, ok: !!condition});

const clean = cleanMessages([{role:'user',content:'hello'}]);
ok('message sanitizer keeps valid user input', clean.length === 1 && clean[0].content === 'hello');
ok('mood parser strips valid tag', parseReply('[mood:wink] heya').mood === 'wink');
const local = await handleChat({messages:[{role:'user',content:'tell me a joke'}]}, {apiKey:''});
ok('local Sans brain responds without API key', local.status === 200 && !!local.json.reply && !!local.json.mood);
const technical = await handleChat({messages:[{role:'user',content:'what is the FPS limit?'}]}, {apiKey:''});
ok('local Sans brain handles technical FPS question', /250/.test(technical.json.reply));
console.log(tests.map(t => `${t.ok ? 'PASS' : 'FAIL'} ${t.name}`).join('\n'));
if (tests.some(t => !t.ok)) process.exit(1);
