import { handleChat } from '../../lib/sans-core.mjs';

const headers = { 'content-type': 'application/json', 'cache-control': 'no-store' };

export default async (req, context) => {
  if (req.method !== 'POST') return new Response(JSON.stringify({ error: 'method' }), { status: 405, headers });
  let body;
  try { body = await req.json(); } catch { return new Response(JSON.stringify({ error: 'bad_request' }), { status: 400, headers }); }
  const ip = (context && context.ip) || req.headers.get('x-nf-client-connection-ip') || 'unknown';
  const { status, json } = await handleChat(body, { apiKey: process.env.ANTHROPIC_API_KEY, model: process.env.ANTHROPIC_MODEL, ip });
  return new Response(JSON.stringify(json), { status, headers });
};
