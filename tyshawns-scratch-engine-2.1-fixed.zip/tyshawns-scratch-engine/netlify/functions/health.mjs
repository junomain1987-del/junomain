export default async () => new Response(JSON.stringify({
  ok: true,
  server: "Tyshawn's Engine Netlify API",
  aiConfigured: !!process.env.ANTHROPIC_API_KEY,
  model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
  scratchProxy: true
}), { status: 200, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
