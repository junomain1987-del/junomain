export default async (req) => {
  const url = new URL(req.url); const id = (url.searchParams.get('id') || '').replace(/[^0-9]/g, '');
  if (!id) return new Response(JSON.stringify({ error: 'missing_id' }), { status: 400, headers: { 'content-type': 'application/json' } });
  try {
    const r = await fetch('https://projects.scratch.mit.edu/' + id);
    return new Response(await r.arrayBuffer(), { status: r.status, headers: { 'content-type': 'application/octet-stream', 'cache-control': 'public, max-age=300' } });
  } catch (e) { return new Response(JSON.stringify({ error: 'scratch_download', message: e.message }), { status: 502, headers: { 'content-type': 'application/json' } }); }
};
