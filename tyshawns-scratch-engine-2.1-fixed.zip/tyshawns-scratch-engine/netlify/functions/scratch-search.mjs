export default async (req) => {
  const url = new URL(req.url);
  const q = (url.searchParams.get('q') || 'trending').slice(0, 160);
  const limit = Math.min(40, Math.max(1, Number(url.searchParams.get('limit') || 24)));
  try {
    const r = await fetch('https://api.scratch.mit.edu/search/projects?q=' + encodeURIComponent(q) + '&mode=trending&language=en&offset=0&limit=' + limit, { headers: { accept: 'application/json' } });
    const text = await r.text();
    return new Response(text, { status: r.status, headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=60' } });
  } catch (e) { return new Response(JSON.stringify({ error: 'scratch_upstream', message: e.message }), { status: 502, headers: { 'content-type': 'application/json' } }); }
};
