// Small visual effects for the landing page: cursor spotlight and 3D tilt.
(function () {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var root = document.documentElement, raf = 0, x = 0, y = 0;
  window.addEventListener('pointermove', function (e) {
    x = e.clientX; y = e.clientY;
    if (!raf) raf = requestAnimationFrame(function () { raf = 0; root.style.setProperty('--mx', x + 'px'); root.style.setProperty('--my', y + 'px'); });
  }, { passive: true });

  Array.prototype.forEach.call(document.querySelectorAll('.tilt'), function (card) {
    card.addEventListener('pointermove', function (e) {
      var r = card.getBoundingClientRect(), px = (e.clientX - r.left) / r.width - .5, py = (e.clientY - r.top) / r.height - .5;
      card.style.transform = 'perspective(700px) rotateX(' + (-py * 5).toFixed(2) + 'deg) rotateY(' + (px * 6).toFixed(2) + 'deg) translateY(-3px)';
    });
    card.addEventListener('pointerleave', function () { card.style.transform = ''; });
  });
})();
