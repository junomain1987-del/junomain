# Tyshawn's Engine 2.0

A high-quality Scratch game hub powered by the TurboWarp runtime.

## Run it locally

1. Install Node.js.
2. In this folder run `npm install`.
3. Run `npm start`.
4. Open **http://localhost:8080/** — use the URL with the trailing slash if your local file server shows a directory listing.

The included `serve.mjs` now provides the local `/api/sans`, `/api/health`, `/api/scratch-search`, and `/api/scratch-project` routes, so the AI and Scratch searcher do not depend on the page being deployed to Netlify.

## AI

Set `ANTHROPIC_API_KEY` in the server environment for real AI answers. You can optionally set `ANTHROPIC_MODEL` to the model available in your Anthropic account. The browser never receives the API key.

Without the key, the chat uses a local Sans brain that still answers common questions and never leaves the chat blank. For full model intelligence, configure the key.

## Expression folder

`expressions/` contains 30 replaceable emotions. Replace `happy.svg`, `angry.svg`, etc. with your own `happy.png`, `angry.webp`, and so on. The chat checks PNG, WEBP, JPG, JPEG, GIF, then SVG, and falls back to a built-in vector face.

## Scratch searcher

The Discover tab proxies the public Scratch project search and project download through `/api/scratch-search` and `/api/scratch-project`. Search a project, press **Add & Play**, and the `.sb3` is stored in the browser vault and launched in the engine.

## Performance

The player uses TurboWarp custom script rates up to 250 FPS. The player now shows two meters: Engine FPS (script execution rate) and Display FPS (browser presentation rate). A 60 Hz display can still show about 60 visible frames even while the Scratch engine executes scripts faster.

## Deployment

Netlify is configured with the same API routes. Put `ANTHROPIC_API_KEY` in Netlify Environment Variables and redeploy. `ANTHROPIC_MODEL` can be added there as well.
