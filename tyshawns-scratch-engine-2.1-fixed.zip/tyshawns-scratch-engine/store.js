// Hands an uploaded .sb3 from the landing page to the player tab.
// Both pages are on the same origin, so IndexedDB is shared between them.
(function () {
  var DB = 'tyshawns-scratch-engine', STORE = 'games', MAX_AGE = 24 * 3600 * 1000;

  function open() {
    return new Promise(function (resolve, reject) {
      var req = indexedDB.open(DB, 1);
      req.onupgradeneeded = function () { req.result.createObjectStore(STORE); };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error || new Error('Could not open browser storage')); };
    });
  }
  function tx(db, mode, fn) {
    return new Promise(function (resolve, reject) {
      var t = db.transaction(STORE, mode), out = fn(t.objectStore(STORE));
      t.oncomplete = function () { resolve(out && out.result !== undefined ? out.result : undefined); };
      t.onerror = t.onabort = function () { reject(t.error || new Error('Storage failed')); };
    });
  }

  window.GameStore = {
    // Returns an id the player page can use: play.html?id=<id>
    put: function (name, buffer) {
      var id = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      return open().then(function (db) {
        return tx(db, 'readwrite', function (s) {
          s.openCursor().onsuccess = function (e) {      // prune old uploads
            var c = e.target.result;
            if (c) { if (Date.now() - (c.value.t || 0) > MAX_AGE) c.delete(); c.continue(); }
          };
          return s.put({ name: name, data: buffer, t: Date.now() }, id);
        });
      }).then(function () { return id; });
    },
    get: function (id) {
      return open().then(function (db) { return tx(db, 'readonly', function (s) { return s.get(id); }); });
    }
  };

  window.formatSize = function (n) {
    return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  };
})();
