# Tyshawn's Engine — Bot Expression Library

There are 30 expression slots. Replace any matching `.svg` with your own image, or place a file with the same name in PNG/WEBP/JPG/JPEG/GIF format. The chat checks those formats in that order and falls back to the SVG.

Examples: `happy.png`, `angry.webp`, `sleepy.jpg`, `surprised.svg`.

Keep the expression filename exactly the same as the emotion name so the AI mood tag can select it.
