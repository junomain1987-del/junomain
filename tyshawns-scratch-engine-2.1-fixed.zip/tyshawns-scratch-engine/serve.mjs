// Local development server with the same API paths used by the deployed site.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { handleChat } from './lib/sans-core.mjs';

const root = fileURLToPath(new URL('.', import.meta.url));
const types = { '.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json','.wasm':'application/wasm','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif' };
const PORT = Number(process.env.PORT || 8080);
const jsonHeaders = { 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', 'access-control-allow-origin':'*' };

function send(res,status,data,headers={}) { res.writeHead(status,{...headers}); res.end(data); }
async function body(req){ return await new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>1_500_000){reject(new Error('body too large'));req.destroy()}});req.on('end',()=>resolve(s));req.on('error',reject)}) }
async function scratchSearch(url,res){
  const q=(url.searchParams.get('q')||'trending').slice(0,160), limit=Math.min(40,Math.max(1,Number(url.searchParams.get('limit')||24)));
  const target='https://api.scratch.mit.edu/search/projects?q='+encodeURIComponent(q)+'&mode=trending&language=en&offset=0&limit='+limit;
  try { const r=await fetch(target,{headers:{accept:'application/json','user-agent':'TyshawnsEngine/2.0'}}); const txt=await r.text(); send(res,r.status,txt,{...jsonHeaders}); } catch(e){ send(res,502,JSON.stringify({error:'scratch_upstream',message:e.message}),jsonHeaders); }
}
async function scratchProject(url,res){
  const id=(url.searchParams.get('id')||'').replace(/[^0-9]/g,''); if(!id)return send(res,400,'missing id',{'content-type':'text/plain'});
  try { const r=await fetch('https://projects.scratch.mit.edu/'+id,{headers:{'user-agent':'TyshawnsEngine/2.0'}}); const buf=Buffer.from(await r.arrayBuffer()); send(res,r.status,buf,{'content-type':'application/octet-stream','cache-control':'public, max-age=300'}); } catch(e){ send(res,502,JSON.stringify({error:'scratch_download',message:e.message}),jsonHeaders); }
}
async function sans(req,res){
  let parsed; try { parsed=JSON.parse(await body(req)||'{}'); } catch { return send(res,400,JSON.stringify({error:'bad_request'}),jsonHeaders); }
  const out=await handleChat(parsed,{apiKey:process.env.ANTHROPIC_API_KEY,model:process.env.ANTHROPIC_MODEL,ip:req.socket.remoteAddress||'local'});
  send(res,out.status,JSON.stringify(out.json),jsonHeaders);
}

createServer(async (req,res)=>{
  try {
    const url=new URL(req.url,'http://localhost');
    if(req.method==='OPTIONS'){return send(res,204,'',{...jsonHeaders,'access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'content-type'})}
    if(url.pathname==='/api/health') return send(res,200,JSON.stringify({ok:true,server:'Tyshawn\'s Engine local API',aiConfigured:!!process.env.ANTHROPIC_API_KEY,model:process.env.ANTHROPIC_MODEL||'claude-sonnet-5-5',scratchProxy:true,chatFallback:true}),jsonHeaders);
    if(url.pathname==='/api/sans'&&req.method==='POST') return sans(req,res);
    if(url.pathname==='/api/scratch-search'&&req.method==='GET') return scratchSearch(url,res);
    if(url.pathname==='/api/scratch-project'&&req.method==='GET') return scratchProject(url,res);
    let p=decodeURIComponent(url.pathname); if(p==='/'||p==='')p='/index.html'; const file=normalize(join(root,p));
    if(!file.startsWith(root))return send(res,403,'Forbidden',{'content-type':'text/plain'});
    const data=await readFile(file); return send(res,200,data,{'content-type':types[extname(file)]||'application/octet-stream'});
  } catch(e) { send(res,404,'Not found',{'content-type':'text/plain'}); }
}).listen(PORT,()=>console.log(`Tyshawn's Engine → http://localhost:${PORT}/`));
